﻿public enum Faction
{
    CSharp,
    Java
}
